function Navbar() {
    return (
      <nav style={{ padding: "10px", background: "#4CAF50", color: "white", textAlign: "center" }}>
        <h1>🌿 Virtual Garden</h1>
      </nav>
    );
  }
  
  export default Navbar;
  