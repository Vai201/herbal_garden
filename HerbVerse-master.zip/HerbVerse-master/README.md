Credits :
https://sketchfab.com/ 
https://bsi.gov.in/
Collaborators:
Parth Patil
Gaurav Mishra
Vaibhav Nemani
Padmashri Panda
